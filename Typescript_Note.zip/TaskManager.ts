// Define a Task interface
interface Task {
  id: number;
  title: string;
  description: string;
  status: string;
}

// Class representing a Task Manager
class TaskManager {
  private tasks: Task[] = [];

  // Add a new task to the task list
  addTask(task: Task): void {
    this.tasks.push(task);
  }

  // Retrieve all tasks from the task list
  getTasks(): Task[] {
    return this.tasks;
  }

  // Find a task by ID
  getTaskById(id: number): Task | undefined {
    return this.tasks.find(task => task.id === id);
  }

  // Update task details
  updateTask(id: number, updatedTask: Partial<Task>): void {
    const index = this.tasks.findIndex(task => task.id === id);
    if (index !== -1) {
      this.tasks[index] = { ...this.tasks[index], ...updatedTask };
    }
  }

  // Delete a task by ID
  deleteTask(id: number): void {
    this.tasks = this.tasks.filter(task => task.id !== id);
  }
}

// Example usage:

// Create a new instance of TaskManager
const taskManager = new TaskManager();

// Add some tasks
taskManager.addTask({ id: 1, title: "Task 1", description: "Description for Task 1", status: "Pending" });
taskManager.addTask({ id: 2, title: "Task 2", description: "Description for Task 2", status: "InProgress" });
taskManager.addTask({ id: 3, title: "Task 3", description: "Description for Task 3", status: "Completed" });

// Retrieve all tasks
console.log("All tasks:", taskManager.getTasks());

// Retrieve a specific task by ID
const task = taskManager.getTaskById(1);
if (task) {
  console.log("Task found:", task);
} else {
  console.log("Task not found");
}

// Update task details
taskManager.updateTask(1, { status: "InProgress" });
console.log("Updated task:", taskManager.getTaskById(1));

// Delete a task
taskManager.deleteTask(2);
console.log("Tasks after deletion:", taskManager.getTasks());